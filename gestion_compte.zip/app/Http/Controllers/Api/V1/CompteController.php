<?php

namespace App\Http\Controllers\Api\V1;

use App\Exceptions\CompteNotFoundException;
use App\Events\ClientCreated;
use App\Exceptions\UnauthorizedAccessException;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreCompteRequest;
use App\Http\Resources\CompteResource;
use App\Models\Client;
use App\Models\Compte;
use App\Traits\ApiResponseTrait;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;


/**
 * @group Comptes
 *
 * APIs pour la gestion des comptes bancaires
 */
class CompteController extends Controller
{
    use ApiResponseTrait;

    /**
     * @OA\Get(
     *     path="/api/v1/comptes/{compteId}",
     *     summary="Récupérer un compte spécifique",
     *     description="Récupère les détails d'un compte spécifique selon les permissions de l'utilisateur. Recherche d'abord en local, puis en serverless si nécessaire.",
     *     operationId="getCompte",
     *     tags={"Comptes"},
     *     security={{"passport": {"read-comptes"}}},
     *     @OA\Parameter(
     *         name="compteId",
     *         in="path",
     *         description="ID du compte à récupérer",
     *         required=true,
     *         @OA\Schema(type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Détails du compte récupérés avec succès",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Compte récupéré avec succès"),
     *             @OA\Property(property="data", ref="#/components/schemas/Compte")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Compte non trouvé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Le compte avec l'ID spécifié n'existe pas"),
     *             @OA\Property(
     *                 property="error",
     *                 @OA\Property(property="code", type="string", example="COMPTE_NOT_FOUND"),
     *                 @OA\Property(property="message", type="string", example="Le compte avec l'ID spécifié n'existe pas"),
     *                 @OA\Property(
     *                     property="details",
     *                     @OA\Property(property="compteId", type="string", example="550e8400-e29b-41d4-a716-446655440000")
     *                 )
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Non authentifié",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Non authentifié")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Accès refusé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Accès non autorisé")
     *         )
     *     )
     * )
     */
    public function show(Request $request, Compte $compte): JsonResponse
    {
        $user = $request->user();

        // Vérifier les permissions selon le rôle
        if ($user->role === 'client') {
            // Les utilisateurs clients ne peuvent voir que leurs propres comptes
            if ($compte->client_id !== $user->client_id) {
                throw new UnauthorizedAccessException("Vous n'avez pas accès à ce compte.");
            }
        }
        // Les admins peuvent voir tous les comptes

        // Stratégie de recherche : local par défaut, serverless si nécessaire
        $compteData = null;
        $searchSource = 'local';

        // Recherche en local d'abord (comptes chèque ou épargne actifs)
        if ($compte->type === 'cheque' || ($compte->type === 'epargne' && $compte->statut === 'actif')) {
            $compteData = $compte;
        } else {
            // Recherche en serverless (simulée pour les comptes épargne archivés)
            $compteData = $this->searchInServerless($compte->id);
            $searchSource = 'serverless';
        }

        if (!$compteData) {
            throw new CompteNotFoundException($compte->id);
        }

        // Log de la stratégie de recherche utilisée
        Log::info('Recherche de compte effectuée', [
            'compte_id' => $compte->id,
            'user_id' => $user->id,
            'search_source' => $searchSource,
            'compte_type' => $compte->type,
            'compte_statut' => $compte->statut,
        ]);

        return $this->successResponse(
            new CompteResource($compteData),
            'Compte récupéré avec succès'
        );
    }

    /**
     * Recherche en serverless (simulée pour les comptes archivés)
     *
     * @param string $compteId
     * @return Compte|null
     */
    private function searchInServerless(string $compteId): ?Compte
    {
        // Simulation de recherche serverless
        // En production, ceci ferait appel à une API serverless (AWS Lambda, etc.)
        Log::info('Recherche serverless simulée', [
            'compte_id' => $compteId,
            'service' => 'AWS_Lambda',
            'endpoint' => 'https://lambda.us-east-1.amazonaws.com/accounts/search'
        ]);

        // Pour la simulation, on retourne le compte s'il existe
        // En réalité, ceci contacterait un service externe
        return Compte::find($compteId);
    }

    /**
     * @OA\Get(
     *     path="/api/v1/comptes",
     *     summary="Lister tous les comptes",
     *     description="Récupère la liste paginée des comptes selon les permissions de l'utilisateur. Admin voit tous les comptes, Client voit uniquement ses comptes.",
     *     operationId="getComptes",
     *     tags={"Comptes"},
     *     security={{"passport": {"read-comptes"}}},
     *     @OA\Parameter(
     *         name="page",
     *         in="query",
     *         description="Numéro de page",
     *         required=false,
     *         @OA\Schema(type="integer", default=1, minimum=1)
     *     ),
     *     @OA\Parameter(
     *         name="limit",
     *         in="query",
     *         description="Nombre d'éléments par page",
     *         required=false,
     *         @OA\Schema(type="integer", default=10, minimum=1, maximum=100)
     *     ),
     *     @OA\Parameter(
     *         name="type",
     *         in="query",
     *         description="Filtrer par type",
     *         required=false,
     *         @OA\Schema(type="string", enum={"epargne", "cheque"})
     *     ),
     *     @OA\Parameter(
     *         name="statut",
     *         in="query",
     *         description="Filtrer par statut",
     *         required=false,
     *         @OA\Schema(type="string", enum={"actif", "bloque", "ferme"})
     *     ),
     *     @OA\Parameter(
     *         name="search",
     *         in="query",
     *         description="Recherche par titulaire ou numéro",
     *         required=false,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Parameter(
     *         name="sort",
     *         in="query",
     *         description="Tri",
     *         required=false,
     *         @OA\Schema(type="string", enum={"dateCreation", "solde", "titulaire"})
     *     ),
     *     @OA\Parameter(
     *         name="order",
     *         in="query",
     *         description="Ordre",
     *         required=false,
     *         @OA\Schema(type="string", enum={"asc", "desc"})
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Liste des comptes récupérée avec succès",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Comptes récupérés avec succès"),
     *             @OA\Property(
     *                 property="data",
     *                 type="array",
     *                 @OA\Items(ref="#/components/schemas/Compte")
     *             ),
     *             @OA\Property(
     *                 property="pagination",
     *                 @OA\Property(property="currentPage", type="integer", example=1),
     *                 @OA\Property(property="totalPages", type="integer", example=3),
     *                 @OA\Property(property="totalItems", type="integer", example=25),
     *                 @OA\Property(property="itemsPerPage", type="integer", example=10),
     *                 @OA\Property(property="hasNext", type="boolean", example=true),
     *                 @OA\Property(property="hasPrevious", type="boolean", example=false)
     *             ),
     *             @OA\Property(
     *                 property="links",
     *                 @OA\Property(property="self", type="string", example="/api/v1/comptes?page=1&limit=10"),
     *                 @OA\Property(property="next", type="string", example="/api/v1/comptes?page=2&limit=10"),
     *                 @OA\Property(property="first", type="string", example="/api/v1/comptes?page=1&limit=10"),
     *                 @OA\Property(property="last", type="string", example="/api/v1/comptes?page=3&limit=10")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Non authentifié",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Non authentifié")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Accès refusé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Accès non autorisé")
     *         )
     *     )
     * )
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        // Validation des paramètres
        $validated = $request->validate([
            'page' => 'integer|min:1',
            'limit' => 'integer|min:1|max:100',
            'type' => 'string|in:epargne,cheque',
            'statut' => 'string|in:actif,bloque,ferme',
            'search' => 'string|nullable',
            'sort' => 'string|in:dateCreation,solde,titulaire',
            'order' => 'string|in:asc,desc',
        ]);

        $query = Compte::with('client');

        // Filtrage selon le rôle de l'utilisateur
        if ($user->role === 'client') {
            // Les utilisateurs clients ne voient que leurs comptes actifs (non supprimés et non bloqués)
            $query->where('client_id', $user->client_id)
                  ->where('statut', '!=', 'bloque')
                  ->whereNull('deleted_at'); // Exclure les comptes supprimés (soft delete)
        }
        // Les admins voient tous les comptes (pas de filtrage supplémentaire)

        // Application des filtres
        if (!empty($validated['type'])) {
            $query->where('type', $validated['type']);
        }

        if (!empty($validated['statut'])) {
            $query->where('statut', $validated['statut']);
        }

        if (!empty($validated['search'])) {
            $search = $validated['search'];
            $query->where(function ($q) use ($search) {
                $q->where('numero', 'like', "%{$search}%")
                  ->orWhereHas('client', function ($clientQuery) use ($search) {
                      $clientQuery->where('nom', 'like', "%{$search}%")
                                  ->orWhere('prenom', 'like', "%{$search}%");
                  });
            });
        }

        // Tri
        $sortField = match($validated['sort'] ?? 'dateCreation') {
            'dateCreation' => 'created_at',
            'solde' => 'solde',
            'titulaire' => 'clients.nom',
            default => 'created_at'
        };

        $order = $validated['order'] ?? 'desc';

        if ($sortField === 'clients.nom') {
            $query->join('clients', 'comptes.client_id', '=', 'clients.id')
                  ->orderBy('clients.nom', $order)
                  ->select('comptes.*');
        } else {
            $query->orderBy($sortField, $order);
        }

        // Pagination
        $perPage = $validated['limit'] ?? 10;
        $comptes = $query->paginate($perPage);

        return $this->paginatedResponse($comptes, CompteResource::class);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/comptes",
     *     summary="Créer un nouveau compte",
     *     description="Crée un nouveau compte bancaire avec vérification du client existant ou création automatique",
     *     operationId="createCompte",
     *     tags={"Comptes"},
     *     security={{"passport": {"write-comptes"}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"type", "soldeInitial", "devise", "client"},
     *             @OA\Property(property="type", type="string", enum={"cheque", "epargne"}, example="cheque"),
     *             @OA\Property(property="soldeInitial", type="number", format="decimal", minimum=10000, example=500000),
     *             @OA\Property(property="devise", type="string", enum={"XOF", "EUR", "USD"}, example="XOF"),
     *             @OA\Property(
     *                 property="client",
     *                 type="object",
     *                 @OA\Property(property="id", type="integer", nullable=true, example=null),
     *                 @OA\Property(property="titulaire", type="string", example="Hawa BB Wane"),
     *                 @OA\Property(property="nci", type="string", example="1980123456789"),
     *                 @OA\Property(property="email", type="string", format="email", example="cheikh.sy@example.com"),
     *                 @OA\Property(property="telephone", type="string", example="+221771234567"),
     *                 @OA\Property(property="adresse", type="string", example="Dakar, Sénégal")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Compte créé avec succès",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Compte créé avec succès"),
     *             @OA\Property(property="data", ref="#/components/schemas/Compte")
     *         )
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Données invalides",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Les données fournies sont invalides"),
     *             @OA\Property(
     *                 property="error",
     *                 @OA\Property(property="code", type="string", example="VALIDATION_ERROR"),
     *                 @OA\Property(property="message", type="string", example="Les données fournies sont invalides"),
     *                 @OA\Property(
     *                     property="details",
     *                     type="object",
     *                     @OA\Property(property="soldeInitial", type="array", @OA\Items(type="string", example="Le solde initial doit être supérieur à 0"))
     *                 )
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Non authentifié",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Non authentifié")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Accès refusé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Accès non autorisé")
     *         )
     *     )
     * )
     */
    public function store(StoreCompteRequest $request): JsonResponse
    {
        return DB::transaction(function () use ($request) {
            $validated = $request->validated();

            // Vérifier si le client existe ou le créer
            $client = $this->findOrCreateClient($validated['client']);

            // Générer l'UUID pour le compte
            $compteId = (string) Str::uuid();

            // Créer le compte
            $compte = Compte::create([
                'id' => $compteId,
                'numero' => null, // Sera généré automatiquement par le mutator
                'type' => $validated['type'],
                'solde' => $validated['soldeInitial'],
                'devise' => $validated['devise'],
                'statut' => 'actif',
                'client_id' => $client->id,
            ]);

            // Créer la transaction initiale de dépôt
            $compte->transactions()->create([
                'id' => (string) Str::uuid(),
                'reference' => 'DEP-' . strtoupper(Str::random(10)),
                'type' => 'depot',
                'montant' => $validated['soldeInitial'],
                'devise' => $validated['devise'],
                'description' => 'Dépôt initial lors de la création du compte',
                'statut' => 'validee',
                'date_transaction' => now(),
                'compte_id' => $compte->id,
            ]);

            Log::info('Nouveau compte créé', [
                'compte_id' => $compte->id,
                'numero_compte' => $compte->numero,
                'client_id' => $client->id,
                'type' => $validated['type'],
                'solde_initial' => $validated['soldeInitial'],
            ]);

            return $this->successResponse(
                new CompteResource($compte),
                'Compte créé avec succès',
                201
            );
        });
    }

    /**
     * Recherche ou crée un client selon les données fournies
     *
     * @param array $clientData
     * @return Client
     */
    private function findOrCreateClient(array $clientData): Client
    {
        // Si un ID de client est fourni, vérifier qu'il existe
        if (!empty($clientData['id'])) {
            $client = Client::find($clientData['id']);
            if (!$client) {
                throw new \InvalidArgumentException("Client avec l'ID {$clientData['id']} n'existe pas.");
            }
            return $client;
        }

        // Créer un nouveau client
        $generatedPassword = Str::random(12);
        $verificationCode = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        $client = Client::create([
            'nom' => $clientData['titulaire'],
            'prenom' => '', // Peut être extrait du nom complet si nécessaire
            'email' => $clientData['email'],
            'telephone' => $clientData['telephone'],
            'adresse' => $clientData['adresse'],
            'date_naissance' => now()->subYears(25)->format('Y-m-d'), // Valeur par défaut
            'user_id' => $this->getCurrentUserId(),
        ]);

        // Déclencher l'événement de création du client
        event(new ClientCreated($client, $generatedPassword, $verificationCode));

        Log::info('Nouveau client créé', [
            'client_id' => $client->id,
            'email' => $client->email,
            'telephone' => $client->telephone,
        ]);

        return $client;
    }

    /**
     * Récupère l'ID de l'utilisateur actuel
     *
     * @return int
     */
    private function getCurrentUserId(): int
    {
        return auth()->id() ?? 1; // Fallback pour les tests
    }

    /**
     * Display the specified resource.
     */
    public function showOld(string $id)
    {
        //
    }

    /**
     * @OA\Patch(
     *     path="/api/v1/comptes/{compteId}",
     *     summary="Mettre à jour partiellement un compte",
     *     description="Permet aux clients de modifier leurs informations personnelles. Tous les champs sont optionnels mais au moins un doit être fourni.",
     *     operationId="updateCompte",
     *     tags={"Comptes"},
     *     security={{"passport": {"write-comptes"}}},
     *     @OA\Parameter(
     *         name="compteId",
     *         in="path",
     *         description="ID du compte à modifier",
     *         required=true,
     *         @OA\Schema(type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="titulaire", type="string", example="Amadou Diallo Junior"),
     *             @OA\Property(
     *                 property="informationsClient",
     *                 type="object",
     *                 @OA\Property(property="telephone", type="string", example="+221771234568"),
     *                 @OA\Property(property="email", type="string", format="email", example="nouveau.email@example.com"),
     *                 @OA\Property(property="password", type="string", format="password", example="nouveauMotDePasse123"),
     *                 @OA\Property(property="nci", type="string", example="1980123456789")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Compte mis à jour avec succès",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Compte mis à jour avec succès"),
     *             @OA\Property(property="data", ref="#/components/schemas/Compte")
     *         )
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Données invalides ou aucun champ fourni",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Les données fournies sont invalides"),
     *             @OA\Property(
     *                 property="error",
     *                 @OA\Property(property="code", type="string", example="VALIDATION_ERROR"),
     *                 @OA\Property(property="message", type="string", example="Au moins un champ de modification doit être fourni")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Accès refusé - compte n'appartient pas à l'utilisateur",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Accès non autorisé")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Compte non trouvé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Le compte avec l'ID spécifié n'existe pas")
     *         )
     *     )
     * )
     */
    public function update(UpdateCompteRequest $request, Compte $compte): JsonResponse
    {
        $user = $request->user();

        // Vérifier les permissions : seuls les propriétaires peuvent modifier
        if ($user->role === 'client') {
            // Les utilisateurs clients ne peuvent modifier que leurs propres comptes
            if ($compte->client_id !== $user->client_id) {
                throw new UnauthorizedAccessException("Vous n'avez pas accès à ce compte.");
            }
        }
        // Les admins peuvent modifier tous les comptes

        return DB::transaction(function () use ($request, $compte) {
            $validated = $request->validated();

            // Mise à jour du titulaire si fourni
            if (isset($validated['titulaire'])) {
                $compte->client->update([
                    'nom' => $validated['titulaire'],
                    'prenom' => '' // Peut être extrait si nécessaire
                ]);
            }

            // Mise à jour des informations client si fournies
            if (isset($validated['informationsClient'])) {
                $clientUpdates = [];

                if (isset($validated['informationsClient']['telephone'])) {
                    $clientUpdates['telephone'] = $validated['informationsClient']['telephone'];
                }

                if (isset($validated['informationsClient']['email'])) {
                    $clientUpdates['email'] = $validated['informationsClient']['email'];
                }

                if (isset($validated['informationsClient']['password'])) {
                    $clientUpdates['password'] = bcrypt($validated['informationsClient']['password']);
                }

                if (isset($validated['informationsClient']['nci'])) {
                    $clientUpdates['nci'] = $validated['informationsClient']['nci'];
                }

                if (!empty($clientUpdates)) {
                    $compte->client->update($clientUpdates);
                }
            }

            // Recharger le compte avec les relations mises à jour
            $compte->load('client');

            Log::info('Compte mis à jour', [
                'compte_id' => $compte->id,
                'user_id' => $user->id,
                'champs_modifies' => array_keys($validated),
            ]);

            return $this->successResponse(
                new CompteResource($compte),
                'Compte mis à jour avec succès'
            );
        });
    }

    /**
     * @OA\Post(
     *     path="/api/v1/comptes/{compteId}/bloquer",
     *     summary="Bloquer un compte épargne",
     *     description="Bloque un compte épargne actif pour une durée déterminée. Seuls les comptes épargne actifs peuvent être bloqués.",
     *     operationId="bloquerCompte",
     *     tags={"Comptes"},
     *     security={{"passport": {"write-comptes"}}},
     *     @OA\Parameter(
     *         name="compteId",
     *         in="path",
     *         description="ID du compte à bloquer",
     *         required=true,
     *         @OA\Schema(type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"motif", "duree", "unite"},
     *             @OA\Property(property="motif", type="string", example="Activité suspecte détectée"),
     *             @OA\Property(property="duree", type="integer", minimum=1, maximum=365, example=30),
     *             @OA\Property(property="unite", type="string", enum={"jours", "semaines", "mois"}, example="mois")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Compte bloqué avec succès",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Compte bloqué avec succès"),
     *             @OA\Property(property="data", type="object",
     *                 @OA\Property(property="id", type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000"),
     *                 @OA\Property(property="statut", type="string", example="bloque"),
     *                 @OA\Property(property="motifBlocage", type="string", example="Activité suspecte détectée"),
     *                 @OA\Property(property="dateBlocage", type="string", format="date-time", example="2025-10-19T11:20:00Z"),
     *                 @OA\Property(property="dateDeblocagePrevue", type="string", format="date-time", example="2025-11-18T11:20:00Z")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Données invalides ou compte ne peut pas être bloqué",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Les données fournies sont invalides")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Accès refusé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Accès non autorisé")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Compte non trouvé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Le compte avec l'ID spécifié n'existe pas")
     *         )
     *     )
     * )
     */
    public function bloquer(BloquerCompteRequest $request, Compte $compte): JsonResponse
    {
        $user = $request->user();

        // Vérifier les permissions : seuls les admins peuvent bloquer
        if ($user->role !== 'admin') {
            throw new UnauthorizedAccessException("Accès non autorisé - seuls les administrateurs peuvent bloquer des comptes.");
        }

        // Vérifier que seul les comptes épargne peuvent être bloqués
        if ($compte->type !== 'epargne') {
            return $this->errorResponse(
                'Seuls les comptes épargne peuvent être bloqués.',
                400
            );
        }

        return DB::transaction(function () use ($request, $compte, $user) {
            $validated = $request->validated();

            // Calculer la date de fin de blocage
            $dateDebut = now();
            $dateFin = $this->calculerDateFinBlocage($dateDebut, $validated['duree'], $validated['unite']);

            // Bloquer le compte
            $compte->update([
                'is_blocked' => true,
                'statut' => 'bloque',
                'motif_blockage' => $validated['motif'],
                'date_debut_blockage' => $dateDebut,
                'date_fin_blockage' => $dateFin,
                'duree_blockage' => $validated['duree'],
                'unite_blockage' => $validated['unite'],
            ]);

            Log::info('Compte bloqué', [
                'compte_id' => $compte->id,
                'numero_compte' => $compte->numero,
                'user_id' => $user->id,
                'motif' => $validated['motif'],
                'duree' => $validated['duree'],
                'unite' => $validated['unite'],
                'date_debut' => $dateDebut,
                'date_fin' => $dateFin,
            ]);

            return $this->successResponse([
                'id' => $compte->id,
                'statut' => $compte->statut,
                'motifBlocage' => $compte->motif_blockage,
                'dateBlocage' => $compte->date_debut_blockage?->toISOString(),
                'dateDeblocagePrevue' => $compte->date_fin_blockage?->toISOString(),
            ], 'Compte bloqué avec succès');
        });
    }

    /**
     * @OA\Post(
     *     path="/api/v1/comptes/{compteId}/debloquer",
     *     summary="Débloquer un compte épargne",
     *     description="Débloque un compte épargne bloqué. Le compte retrouve son statut actif.",
     *     operationId="debloquerCompte",
     *     tags={"Comptes"},
     *     security={{"passport": {"write-comptes"}}},
     *     @OA\Parameter(
     *         name="compteId",
     *         in="path",
     *         description="ID du compte à débloquer",
     *         required=true,
     *         @OA\Schema(type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"motif"},
     *             @OA\Property(property="motif", type="string", example="Vérification complétée")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Compte débloqué avec succès",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Compte débloqué avec succès"),
     *             @OA\Property(property="data", type="object",
     *                 @OA\Property(property="id", type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000"),
     *                 @OA\Property(property="statut", type="string", example="actif"),
     *                 @OA\Property(property="dateDeblocage", type="string", format="date-time", example="2025-10-19T12:00:00Z")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Données invalides ou compte ne peut pas être débloqué",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Les données fournies sont invalides")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Accès refusé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Accès non autorisé")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Compte non trouvé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Le compte avec l'ID spécifié n'existe pas")
     *         )
     *     )
     * )
     */
    public function debloquer(DebloquerCompteRequest $request, Compte $compte): JsonResponse
    {
        $user = $request->user();

        // Vérifier les permissions : seuls les admins peuvent débloquer
        if ($user->role !== 'admin') {
            throw new UnauthorizedAccessException("Accès non autorisé - seuls les administrateurs peuvent débloquer des comptes.");
        }

        // Vérifier que seul les comptes épargne peuvent être débloqués
        if ($compte->type !== 'epargne') {
            return $this->errorResponse(
                'Seuls les comptes épargne peuvent être débloqués.',
                400
            );
        }

        return DB::transaction(function () use ($request, $compte, $user) {
            $validated = $request->validated();

            $dateDeblocage = now();

            // Débloquer le compte
            $compte->update([
                'is_blocked' => false,
                'statut' => 'actif',
                'motif_deblockage' => $validated['motif'],
                'date_deblockage' => $dateDeblocage,
            ]);

            Log::info('Compte débloqué', [
                'compte_id' => $compte->id,
                'numero_compte' => $compte->numero,
                'user_id' => $user->id,
                'motif_deblockage' => $validated['motif'],
                'date_deblockage' => $dateDeblocage,
            ]);

            return $this->successResponse([
                'id' => $compte->id,
                'statut' => $compte->statut,
                'dateDeblocage' => $compte->date_deblockage?->toISOString(),
            ], 'Compte débloqué avec succès');
        });
    }

    /**
     * Calcule la date de fin de blocage selon la durée et l'unité
     *
     * @param \Carbon\Carbon $dateDebut
     * @param int $duree
     * @param string $unite
     * @return \Carbon\Carbon
     */
    private function calculerDateFinBlocage(\Carbon\Carbon $dateDebut, int $duree, string $unite): \Carbon\Carbon
    {
        return match ($unite) {
            'jours' => $dateDebut->copy()->addDays($duree),
            'semaines' => $dateDebut->copy()->addWeeks($duree),
            'mois' => $dateDebut->copy()->addMonths($duree),
            default => $dateDebut->copy()->addDays($duree),
        };
    }

    /**
     * @OA\Delete(
     *     path="/api/v1/comptes/{compteId}",
     *     summary="Supprimer un compte (soft delete)",
     *     description="Effectue une suppression douce du compte. Seul un administrateur peut supprimer un compte. Le compte reste accessible via les requêtes withTrashed() mais n'apparaît plus dans les listes normales.",
     *     operationId="deleteCompte",
     *     tags={"Comptes"},
     *     security={{"passport": {"write-comptes"}}},
     *     @OA\Parameter(
     *         name="compteId",
     *         in="path",
     *         description="ID du compte à supprimer",
     *         required=true,
     *         @OA\Schema(type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Compte supprimé avec succès (soft delete)",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Compte supprimé avec succès"),
     *             @OA\Property(property="data", type="object",
     *                 @OA\Property(property="id", type="string", format="uuid", example="550e8400-e29b-41d4-a716-446655440000"),
     *                 @OA\Property(property="numeroCompte", type="string", example="C00123456"),
     *                 @OA\Property(property="statut", type="string", example="ferme"),
     *                 @OA\Property(property="dateFermeture", type="string", format="date-time", example="2025-10-19T11:15:00Z")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Accès refusé - seuls les administrateurs peuvent supprimer des comptes",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Accès non autorisé - seuls les administrateurs peuvent supprimer des comptes")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Compte non trouvé",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="message", type="string", example="Le compte avec l'ID spécifié n'existe pas")
     *         )
     *     )
     * )
     */
    public function destroy(Request $request, Compte $compte): JsonResponse
    {
        $user = $request->user();

        // Vérifier que seul un administrateur peut supprimer un compte
        if ($user->role !== 'admin') {
            throw new UnauthorizedAccessException("Accès non autorisé - seuls les administrateurs peuvent supprimer des comptes.");
        }

        // Vérifier que le compte n'est pas déjà supprimé
        if ($compte->trashed()) {
            return $this->errorResponse(
                'Le compte est déjà supprimé.',
                400
            );
        }

        return DB::transaction(function () use ($compte, $user) {
            // Effectuer le soft delete
            $compte->delete();

            // Mettre à jour le statut à "ferme"
            $compte->update(['statut' => 'ferme']);

            Log::info('Compte supprimé (soft delete)', [
                'compte_id' => $compte->id,
                'numero_compte' => $compte->numero,
                'user_id' => $user->id,
                'deleted_at' => $compte->deleted_at,
            ]);

            return $this->successResponse([
                'id' => $compte->id,
                'numeroCompte' => $compte->numero,
                'statut' => $compte->statut,
                'dateFermeture' => $compte->deleted_at?->toISOString(),
            ], 'Compte supprimé avec succès');
        });
    }
}
